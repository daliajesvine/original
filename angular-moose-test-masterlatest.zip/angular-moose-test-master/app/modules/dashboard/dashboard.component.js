angular
    .module('moose.dashboard')
    .component('mooseDashboard', {
        controller: DashboardController,
        templateUrl: 'app/modules/dashboard/dashboard.component.html'
    });
function DashboardController($scope, $http) {
    var ctrl = this;
    ctrl.$onInit = function () {
        ctrl.user = {
            fullName: 'Hallo Welt'
        }
        $scope.getAllProducts();
    };
    ctrl.products = [];
    $scope.searchText = "";
    ctrl.category = 1;
    ctrl.currentPage = 0;
    ctrl.pageSize = 10;
    $scope.sort = "relevance";
    ctrl.products = [];
    var imageUrl = "https://www.real.de/lebensmittelshop";
    ctrl.productUrl = "https://api.efood.real.de/api/v2/real/products/search?query="
    $scope.getAllProducts = function () {
        var query = $scope.searchText + ":" + $scope.sort + ":category:" + ctrl.category;
        var productUrl = ctrl.productUrl + query + "&currentPage=" + ctrl.currentPage + "&pageSize=" + ctrl.pageSize;
        console.log("***Inside controller" + productUrl);
        $http.defaults.useXDomain = true;
        $http.get(productUrl)
            .then(function (response) {
                $scope.products = [];
                for (i = 0; i < response.data.products.length; i++) {
                    var item = response.data.products[i];
                    // for (j = 0; j < item.images.length; j++) {
                    var product = new Object();
                    product.description = item.description;
                    product.url = imageUrl + item.images[0].url;
                    product.name = item.name;
                    ctrl.products[i] = product;
                    // }
                }
                console.log(JSON.stringify(ctrl.products))
                $scope.products = ctrl.products;
            });
    }
    $scope.listOfOrderList = [];
    $scope.listOfCurrentOrderList = [];
    $scope.currentOrderListName = "";
    $scope.defaultList = [];
    $scope.product;
    $scope.populateSelected = function (product) {
        $scope.product = product;
    }
    $scope.addToList = function (type) {
        console.log(type);
        $('#myModal').modal('toggle');
        if ($scope.currentOrderListName == "" && type == 'default') {
            $scope.defaultList.push($scope.product);
        }
        console.log($scope.defaultList)
    }
    $scope.getSortedItems = function (sortingText) {
        $scope.sort = sortingText;
        $scope.getAllProducts();
    }
}