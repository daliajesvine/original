// CONFIGURATIONS
require('./endpoints');