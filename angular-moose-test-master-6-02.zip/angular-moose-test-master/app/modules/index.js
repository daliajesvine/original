require('./dashboard/dashboard.module');
require('./dashboard/dashboard.component');

require('./header/header.component');

require('./sidebar/sidebar.component');