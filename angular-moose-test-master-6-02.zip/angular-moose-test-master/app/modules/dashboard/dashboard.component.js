angular
    .module('moose.dashboard')
    .component('mooseDashboard', {
        controller: DashboardController,
        templateUrl: 'app/modules/dashboard/dashboard.component.html'
    });
function DashboardController($scope, $http, $rootScope) {
    var ctrl = this;
    ctrl.$onInit = function () {
        ctrl.user = {
            fullName: 'Hallo Welt'
        }
        $rootScope.getAllProducts($scope.searchText);
    };
    $scope.getHome = function () {
        $scope.showView = false;
    }
    ctrl.products = [];
    $scope.searchText = "";
    ctrl.category = 1;
    ctrl.currentPage = 0;
    ctrl.pageSize = 10;
    $scope.sort = "relevance";
    ctrl.products = [];
    var imageUrl = "https://www.real.de/lebensmittelshop";
    ctrl.productUrl = "https://api.efood.real.de/api/v2/real/products/search?query="
    $rootScope.getAllProducts = function (searchText) {
        $scope.searchText = searchText;
        var query = $scope.searchText + ":" + $scope.sort + ":category:" + ctrl.category;
        var productUrl = ctrl.productUrl + query + "&currentPage=" + ctrl.currentPage + "&pageSize=" + ctrl.pageSize;
        $http.defaults.useXDomain = true;
        $http.get(productUrl)
            .then(function (response) {
                $scope.products = [];
                for (i = 0; i < response.data.products.length; i++) {
                    var item = response.data.products[i];
                    var product = new Object();
                    product.description = item.description;
                    product.url = imageUrl + item.images[0].url;
                    product.name = item.name;
                    product.brand = item.brand;
                    product.numberContentUnits = item.numberContentUnits;
                    product.contentUnit = item.contentUnit;
                    product.quantity = product.numberContentUnits + product.contentUnit;
                    product.currency = item.price.formattedValue;
                    product.priceValue = item.price.value;
                    product.price = product.currency + product.priceValue;
                    ctrl.products[i] = product;
                }
                console.log(JSON.stringify(ctrl.products))
                $scope.products = ctrl.products;
            }, function (reason) {
                console.log(reason);
            });
    }
    $scope.listOfOrderList = [];
    $scope.listOfCurrentOrderList = [];
    $scope.currentOrderListName = "";
    $scope.defaultList = [];
    $scope.product;
    $scope.populateSelected = function (product) {
        $scope.product = product;
    }
    $rootScope.getView = function () {
        console.log("inside")
        $scope.showView = true;
    }
    $scope.showNewOrderList = false;
    $scope.showDefault = false;
    $scope.showExistingList = false;
    $scope.showView = false;
    $scope.addToList = function (type) {
        console.log(type);
        if (type == 'default') {
            // $scope.defaultList.push($scope.product);
            // $('#myModal').modal('toggle');
            $scope.currentOrderListName = "Default List";
            $scope.showDefault = true;
        } else if (type == 'new') {
            $scope.showNewOrderList = true;
        } else if (type == 'exist') {
            $scope.showExistingList = true;
        }
        console.log($scope.listOfOrderList)
    }
    $scope.duplicateList = false;
    $scope.addToCurrentList = function (type, name) {
        console.log($scope.currentOrderListName, name);
        if (type == 'edit') {
            for (i = 0; i < $scope.listOfOrderList.length; i++) {
                if ($scope.listOfOrderList[i].name == name) $scope.listOfOrderList[i].list.push($scope.product);
            }
            $('#myModal').modal('toggle');
            $scope.showNewOrderList = false;
            $scope.showDefault = false;
            $scope.currentOrderListName = '';
            $scope.showExistingList = false;
        } else if (type == 'new') {
            for (i = 0; i < $scope.listOfOrderList.length; i++) {
                if ($scope.listOfOrderList[i].name == name) $scope.duplicateList = true;
            }
            if (!$scope.duplicateList) {
                var list = [];
                list.push($scope.product)
                $scope.listOfOrderList.push({ name: name, list: list });
                $('#myModal').modal('toggle');
                $scope.showNewOrderList = false;
                $scope.showDefault = false;
                $scope.currentOrderListName = '';
                $scope.showExistingList = false;
            }
        } else {
            var list = [];
            list.push($scope.product)
            $scope.listOfOrderList.push({ name: name, list: list });
            $('#myModal').modal('toggle');
            $scope.showNewOrderList = false;
            $scope.showDefault = false;
            $scope.currentOrderListName = '';
            $scope.showExistingList = false;
        }
    }
    $scope.cancel = function () {
        $scope.currentOrderListName = '';
        $scope.showNewOrderList = false;
        $scope.showDefault = false;
        $scope.showExistingList = false;
        $scope.duplicateList = false;
    }
    $scope.makeFalse = function () {
        $scope.duplicateList = false;
    }
    $scope.getSortedItems = function (sortingText) {
        $scope.sort = sortingText;
        $rootScope.getAllProducts($scope.searchText);
    }
}