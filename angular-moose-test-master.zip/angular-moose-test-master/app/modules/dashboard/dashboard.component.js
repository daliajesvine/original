angular
    .module('moose.dashboard')
    .component('mooseDashboard', {
        controller: DashboardController,
        templateUrl: 'app/modules/dashboard/dashboard.component.html'
    });
function DashboardController($scope, $http, $rootScope) {
    var ctrl = this;
    ctrl.$onInit = function () {
        ctrl.user = {
            fullName: 'Hallo Welt'
        }
        $rootScope.getAllProducts($scope.searchText);
    };
    //To display the home screen
    $scope.getHome = function () {
        $scope.showView = false;
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            var list = [];
            list = list.concat($scope.listOfOrderList[i].list);
            $scope.listOfOrderList[i].filterList = list;
            $scope.listOfOrderList[i].searchText = '';
        }
    }
    ctrl.products = [];
    $scope.searchText = "";
    ctrl.category = 1;
    ctrl.currentPage = 0;
    ctrl.pageSize = 10;
    $scope.sort = "relevance";
    ctrl.products = [];
    var imageUrl = "https://www.real.de/lebensmittelshop";
    ctrl.productUrl = "https://api.efood.real.de/api/v2/real/products/search?query="
    //Retrieve the product data from API
    $rootScope.getAllProducts = function (searchText) {
        $scope.searchText = searchText;
        var query = $scope.searchText + ":" + $scope.sort + ":category:" + ctrl.category;
        var productUrl = ctrl.productUrl + query + "&currentPage=" + ctrl.currentPage + "&pageSize=" + ctrl.pageSize;
        $http.defaults.useXDomain = true;
        $http.get(productUrl)
            .then(function (response) {
                $scope.products = [];
                for (i = 0; i < response.data.products.length; i++) {
                    var item = response.data.products[i];
                    var product = new Object();
                    product.description = item.description;
                    product.url = imageUrl + item.images[0].url;
                    product.name = item.name;
                    product.brand = item.brand;
                    product.numberContentUnits = item.numberContentUnits;
                    product.contentUnit = item.contentUnit;
                    product.quantity = product.numberContentUnits + product.contentUnit;
                    product.currency = item.price.formattedValue;
                    product.priceValue = item.price.value;
                    product.price = product.currency + product.priceValue;
                    ctrl.products[i] = product;
                }
                $scope.products = ctrl.products;
            }, function (reason) {
            });
    }
    $scope.listOfOrderList = [];
    $scope.listOfCurrentOrderList = [];
    $scope.currentOrderListName = "";
    $scope.defaultList = [];
    $scope.product;
    $scope.populateSelected = function (product) {
        $scope.product = product;
    }
    $rootScope.getView = function () {
        $scope.showView = true;
    }
    $scope.showNewOrderList = false;
    $scope.showDefault = false;
    $scope.showExistingList = false;
    $scope.showView = false;
    $scope.addToList = function (type) {
        if (type == 'default') {
            $scope.currentOrderListName = "Default List";
            $scope.showDefault = true;
        } else if (type == 'new') {
            $scope.showNewOrderList = true;
        } else if (type == 'exist') {
            $scope.showExistingList = true;
        }
    }

    $scope.duplicateList = false;
    $scope.addToCurrentList = function (type, name) {
        //add to existing list
        if (type == 'edit') {
            for (i = 0; i < $scope.listOfOrderList.length; i++) {
                if ($scope.listOfOrderList[i].name == name) {
                    $scope.listOfOrderList[i].list.push($scope.product);
                    $scope.listOfOrderList[i].filterList.push($scope.product);
                }
            }
            $('#myModal').modal('toggle');
            $scope.showNewOrderList = false;
            $scope.showDefault = false;
            $scope.currentOrderListName = '';
            $scope.showExistingList = false;
            //create new list
        } else if (type == 'new') {
            for (i = 0; i < $scope.listOfOrderList.length; i++) {
                if ($scope.listOfOrderList[i].name == name) $scope.duplicateList = true;
            }
            if (!$scope.duplicateList) {
                var list = [];
                var filterList = [];
                list.push($scope.product)
                filterList.push($scope.product)
                $scope.listOfOrderList.push({ name: name, list: list, newname: name, searchText: '', filterList: filterList, isEdit: false, duplicateList: false });
                $('#myModal').modal('toggle');
                $scope.showNewOrderList = false;
                $scope.showDefault = false;
                $scope.currentOrderListName = '';
                $scope.showExistingList = false;
            }
        }
        //add products to default list
        else {
            var list = [];
            list.push($scope.product)
            var filterList = [];
            filterList.push($scope.product)
            $scope.listOfOrderList.push({ name: name, list: list, newname: name, searchText: '', filterList: filterList, isEdit: false, duplicateList: false });
            $('#myModal').modal('toggle');
            $scope.showNewOrderList = false;
            $scope.showDefault = false;
            $scope.currentOrderListName = '';
            $scope.showExistingList = false;
        }
    }
    //search function in shopping list
    $scope.getFilterData = function (searchText, name) {
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            if ($scope.listOfOrderList[i].name == name) {
                var list = [];
                for (j = 0; j < $scope.listOfOrderList[i].list.length; j++) {
                    if ($scope.listOfOrderList[i].list[j].name.toLowerCase().indexOf(searchText.toLowerCase()) != -1) list.push($scope.listOfOrderList[i].list[j]);
                }
                $scope.listOfOrderList[i].filterList = list;
            }
        }
    }
    $scope.cancel = function () {
        $scope.currentOrderListName = '';
        $scope.showNewOrderList = false;
        $scope.showDefault = false;
        $scope.showExistingList = false;
        $scope.duplicateList = false;
    }
    //adding duplicate list name
    $scope.makeFalse = function () {
        $scope.duplicateList = false;
    }
    $scope.getSortedItems = function (sortingText) {
        $scope.sort = sortingText;
        $rootScope.getAllProducts($scope.searchText);
    }
    $rootScope.getLength = function () {
        return $scope.listOfOrderList.length;
    }
    $scope.remove = function (name, item) {
        var childIndex = 0;
        var parentIndex = 0;
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            if ($scope.listOfOrderList[i].name == name) {
                parentIndex = i;
                for (j = 0; j < $scope.listOfOrderList[i].list.length; j++) {
                    if ($scope.listOfOrderList[i].list[j] == item) childIndex = j;
                }
            }
        }
        $scope.listOfOrderList[parentIndex].list.splice(childIndex, 1);
        $scope.listOfOrderList[parentIndex].filterList.splice(childIndex, 1);
    }
    $scope.changeName = function (newname, index) {
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            if ($scope.listOfOrderList[i].name == newname) $scope.listOfOrderList[index].duplicateList = true;
        } if (!$scope.listOfOrderList[index].duplicateList) {
            $scope.listOfOrderList[index].name = newname;

            $scope.listOfOrderList[index].isEdit = false;
        }
    }
    $scope.makeDuplicateFalse = function () {
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            $scope.listOfOrderList[i].duplicateList = false;
        }
    }
    $scope.removeOrder = function (index) {
        $scope.listOfOrderList.splice(index, 1)
    }
    //revert to old list name if isedit is cancelled
    $scope.changeEdit = function (type, index) {
        $scope.listOfOrderList[index].isEdit = type;
        $scope.listOfOrderList[index].duplicateList = false;
        for (i = 0; i < $scope.listOfOrderList.length; i++) {
            $scope.listOfOrderList[i].newname = $scope.listOfOrderList[i].name;
        }
    }
}