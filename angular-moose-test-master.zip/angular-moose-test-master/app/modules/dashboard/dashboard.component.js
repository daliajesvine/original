angular
.module('moose.dashboard')
.component('mooseDashboard', {
   controller: DashboardController,
   templateUrl: 'app/modules/dashboard/dashboard.component.html'
});

function DashboardController($scope, $http) {
var ctrl = this;

ctrl.$onInit = function() {
   ctrl.user = {
       fullName: 'Hallo Welt'
   }
   
   ctrl.getAllProducts();
};
ctrl.products = [];
ctrl.searchText = "food";
ctrl.category = 1;
ctrl.currentPage = 0;
ctrl.pageSize = 10;
ctrl.sort = "relevance";
ctrl.products = [];
var imageUrl= "https://www.real.de/lebensmittelshop/images";
ctrl.productUrl = "https://api.efood.real.de/api/v2/real/products/search?query="
ctrl.getAllProducts = function () {
   ctrl.query =  ctrl.searchText + ":" + ctrl.sort + ":category:" + ctrl.category;
   ctrl.productUrl = ctrl.productUrl + ctrl.query + "&currentPage=" + ctrl.currentPage + "&pageSize=" + ctrl.pageSize;
   console.log("****************************Inside controller" +  ctrl.productUrl);
   $http.defaults.useXDomain = true;
   $http.get(ctrl.productUrl)
           .then(function(response)  {
            for (i = 0; i < response.data.products.length; i++) {
                var product = new Object();
                var element = response.data.products[0];
                product.description = element.description;
                product.url = imageUrl + element.images[0].url;
                product.name = element.name;
                ctrl.products.push(product);
            } 
            console.log(JSON.stringify(ctrl.products));
            $scope.products = ctrl.products;
        });
            
    }
}
